"""2022年5月29日18:11:00"""
import os #控制
import sys #系统
import calendar #日历
import random #随机数,目前是只有赌场风云和诺亚要用

def time():
    yy = int(input("输入年份: ")) # 输入指定年月
    mm = int(input("输入月份: "))
    print(calendar.month(yy,mm)) # 显示日历

print("本程序由饺影开发,qq:3044067398")
tool = 1
while tool == 1:
    temp = input("A:\\>")
    user_input = (str(temp))
    if user_input == "help":
        print("comp         计算器\n"
              "time         日历\n"
              "game         游戏")
    
    if user_input == "comp": #内置计算器
        def add(x, y): #相加
            return x + y
        def subtract(x, y): #相减
            return x - y
        def multiply(x, y): #相乘
            return x * y
        def divide(x, y): #相除
            return x / y
        def wang():
            num1 = int(input("输入第一个数字: "))
            num2 = int(input("输入第二个数字: "))
            print(num1,"+",num2,"=", add(num1,num2))
        while tool == 1:
            print("选择运算：")
            print("1、相加")
            print("2、相减")
            print("3、相乘")
            print("4、相除")
            print("5、关闭程序")
            choice = input("输入你的选择(1/2/3/4/5):")
            if choice == '1':
                wang()
            if choice == '2':
                wang()
            if choice == '3':
                wang()
            if choice == '4':
                wang()
                break
            else:
                print("无效")

    if user_input == "time": #内置日历程序
        yy = int(input("输入年份: ")) # 输入指定年月
        mm = int(input("输入月份: "))
        print(calendar.month(yy,mm)) # 显示日历

    
    if user_input == "game": #选择游戏
        while tool == 1: #游戏模块的循环
            print("1        赌场风云\n"
                  "2        退出程序")
            user_input_game = (int(input("A:\\game\\>")))
            if user_input_game == 1: #赌场风云的内部选择
                print("go        开始游戏\n"
                      "exit      关闭游戏")
                user_input_game_1 = (str(input("A:\\game\\bat\\>")))
                if user_input_game_1 == "go":
                    """-----赌场风云复刻版游戏本体-----"""
                    chip = 5
                    while chip > 0:
                        print("你有["+str(chip)+"]个筹码")
                        answer = random.randint(1,6)
                        print("答案是1到6之间")
                        user_input_game_赌场风云 = (int(input(">>>")))
                        if user_input_game_赌场风云 == answer:
                            print("你答对了")
                            chip = chip + 1
                            answer = random.randint(1,6)
                        else:
                            print("你答错了")
                            chip = chip - 1
                            answer = random.randint(1,6)
        
            if user_input_game == 2:
                break
    if user_input == "wwssaadd":
        while tool == 1:
            user_input = (str(input("A:\\system\\>")))
            if user_input == "1":
                print("好家伙,居然打开了测试模式")
            if user_input == "2":
                print("1        测试\n"
                      "2        帮助\n"
                      "3        日历")
            if user_input == "3":
                time()


 
    

